# Summary

- [Welcome](./welcome.md)
- [How We Work](process/how-we-work.md)
- [Appendix](appendix.md)
